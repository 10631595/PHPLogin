<?php
session_start();

if ($_SESSION["checkuser"] === "login")
	{
		echo "";
	} else {
		header("Location: http://localhost/index.php");
	}
?>

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<title>Admin Portal</title>
</head>
<body>
	<div class="container text-light mt-5">
		<div class="row justify-content-md-center">
			<div class="col-md-5 bg-dark p-3">
				<h1>Admin Portal</h1>
				<p>Welcome to the Admin Portal! <br></br>No content exists here yet, so come back soon.</p>
				<form action="logout.php" method="post">
					<button type="logout" class="btn btn-primary">Logout</button>
				</form>
			</div>
		</div>
	</div>
</body>